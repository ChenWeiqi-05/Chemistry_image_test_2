Origin: https://github.com/google/flatbuffers/tree/v23.5.9
